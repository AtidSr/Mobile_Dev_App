package com.somesteak.finalm;

public class Book {

    private String title;
    private String author;
    private int latest;
    private int owned;

    public Book(String title, String author, int latest, int owned) {
        this.title = title;
        this.author = author;
        this.latest = latest;
        this.owned = owned;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getLatest() {
        return latest;
    }

    public void setLatest(int latest) {
        this.latest = latest;
    }

    public int getOwned() {
        return owned;
    }

    public void setOwned(int owned) {
        this.owned = owned;
    }
}
