package com.somesteak.finalm;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class BookHolder extends RecyclerView.ViewHolder {
    private TextView txtName, txtDistance, txtGravity, txtDiameter;
    public BookHolder(View itemView) {
        super(itemView);
        txtName = itemView.findViewById(R.id.txtName);
        txtDistance = itemView.findViewById(R.id.txtDistance);
        txtGravity = itemView.findViewById(R.id.txtGravity);
        txtDiameter = itemView.findViewById(R.id.txtDiameter);
    }

    public void setDetails(Book book) {
        txtName.setText(book.getTitle());
        txtDistance.setText(book.getAuthor());
        txtGravity.setText("" + book.getLatest());
        txtDiameter.setText("" + book.getOwned());
    }
}
