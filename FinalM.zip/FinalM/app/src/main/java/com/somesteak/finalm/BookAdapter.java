package com.somesteak.finalm;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class BookAdapter extends RecyclerView.Adapter<BookHolder>{
    private Context context;
    private ArrayList<Book> books;

    public BookAdapter(Context context, ArrayList < Book > books) {
        this.context = context;
        this.books = books;
    }


    @NonNull
    @Override
    public BookHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_row, viewGroup, false);
        return new BookHolder(view);    }

    @Override
    public void onBindViewHolder(@NonNull BookHolder bookHolder, int i) {
        Book book = books.get(i);
        bookHolder.setDetails(book);
    }

    @Override
    public int getItemCount() {
        return books.size();
    }
}
